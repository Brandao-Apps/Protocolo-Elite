-- Run this in your Supabase SQL editor to create the table
CREATE TABLE IF NOT EXISTS study_progress (
  user_id TEXT PRIMARY KEY DEFAULT 'default',
  checks JSONB DEFAULT '{}',
  boxes JSONB DEFAULT '{}',
  streak INTEGER DEFAULT 0,
  last_activity TEXT,
  total_xp INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS but allow all operations for anon key
ALTER TABLE study_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all for anon" ON study_progress
  FOR ALL USING (true) WITH CHECK (true);
